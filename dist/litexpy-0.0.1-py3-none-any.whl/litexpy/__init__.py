"""Placeholder package for litexpy."""

__version__ = "0.0.1"
